<?php
include 'includes/header.php';
include 'includes/db.php';

// Obtener todas las hermandades
$hermandades = $pdo->query("SELECT * FROM hermandades ORDER BY dia ASC, hora_salida ASC")->fetchAll();

// Procesar formulario para añadir nueva hermandad
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'crear') {
  $nombre = $_POST['nombre'];
  $nombre_oficial = $_POST['nombre_oficial'];
  $fundacion = $_POST['fundacion'];
  $hermano_mayor = $_POST['hermano_mayor'];
  $lugar_salida = $_POST['lugar_salida'];
  $dia = $_POST['dia'];
  $hora_salida = $_POST['hora_salida'];
  $estado = $_POST['estado'];
  
  // Procesar escudo
  $escudo = null;
  if (!empty($_FILES['escudo']['name'])) {
    $target_dir = "../uploads/";
    if (!is_dir($target_dir)) {
      mkdir($target_dir, 0777, true);
    }
    $ext = pathinfo($_FILES['escudo']['name'], PATHINFO_EXTENSION);
    $escudo = "escudo_" . uniqid() . "." . $ext;
    $target_file = $target_dir . $escudo;
    
    if (move_uploaded_file($_FILES['escudo']['tmp_name'], $target_file)) {
      // Archivo subido correctamente
    } else {
      echo "<div class='alert alert-danger'>Error al subir el escudo</div>";
      $escudo = null;
    }
  }
  
  // Procesar foto
  $foto = null;
  if (!empty($_FILES['foto']['name'])) {
    $target_dir = "../uploads/";
    if (!is_dir($target_dir)) {
      mkdir($target_dir, 0777, true);
    }
    $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
    $foto = "foto_" . uniqid() . "." . $ext;
    $target_file = $target_dir . $foto;
    
    if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
      // Archivo subido correctamente
    } else {
      echo "<div class='alert alert-danger'>Error al subir la foto</div>";
      $foto = null;
    }
  }
  
  // Insertar en la base de datos
  $stmt = $pdo->prepare("INSERT INTO hermandades (nombre, nombre_oficial, escudo, foto, fundacion, hermano_mayor, lugar_salida, dia, hora_salida, estado) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  $stmt->execute([
    $nombre, 
    $nombre_oficial, 
    $escudo, 
    $foto, 
    $fundacion, 
    $hermano_mayor, 
    $lugar_salida, 
    $dia, 
    $hora_salida, 
    $estado
  ]);
  
  header("Location: index.php");
  exit;
}

// Procesar formulario para editar hermandad
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'editar') {
  $id = $_POST['id'];
  $dia = $_POST['dia'];
  $hora_salida = $_POST['hora_salida'];
  $estado = $_POST['estado'];
  
  $stmt = $pdo->prepare("UPDATE hermandades SET dia = ?, hora_salida = ?, estado = ? WHERE id = ?");
  $stmt->execute([$dia, $hora_salida, $estado, $id]);
  
  header("Location: index.php");
  exit;
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
   <h2 class="mb-0 fs-2 fs-md-3 fs-lg-2">Gestión de Hermandades</h2>
</div>

<div class="row">
  <!-- Listado de hermandades -->
  <div class="col-md-8">
    <div class="card shadow-sm mb-4">
      <div class="card-header bg-primary text-white">
        <strong>Listado de Hermandades</strong>
      </div>
      <div class="card-body p-2">
		  <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
				<th></th>
              <th>Nombre</th>
              <th>Día</th>
              <th>Hora</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($hermandades as $h): ?>
              <tr>
				<td><img src="../uploads/<?= htmlspecialchars($h['escudo']) ?>" height="50px"/></td>
                <td class="fw-bold"><?= htmlspecialchars($h['nombre']) ?></td>
                <td><?= $h['dia'] ?></td>
                <td><?= $h['hora_salida'] ?></td>
                <td><?= ucfirst($h['estado']) ?></td>
                <td>
                  <button class="btn btn-sm btn-warning btn-editar" data-bs-toggle="modal" data-bs-target="#editarModal" data-h='<?= json_encode($h) ?>'>✏️</button>
                  <a href="recorridos.php?id=<?= $h['id'] ?>" class="btn btn-sm btn-primary">🗺️</a>
                  <a href="pasos.php?id=<?= $h['id'] ?>" class="btn btn-sm btn-secondary">Pasos</a>
                </td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
		  </div>
      </div>
    </div>
  </div>

  <!-- Formulario para nueva hermandad -->
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-header bg-success text-white">
        <strong>Nueva Hermandad</strong>
      </div>
      <div class="card-body">
        <form method="post" enctype="multipart/form-data">
          <input type="hidden" name="accion" value="crear">
          
          <div class="mb-2">
            <label class="form-label">Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
          </div>
          
          <div class="mb-2">
            <label class="form-label">Nombre Oficial</label>
            <textarea name="nombre_oficial" class="form-control" rows="2"></textarea>
          </div>
          
          <div class="mb-2">
            <label class="form-label">Escudo</label>
            <input type="file" name="escudo" class="form-control">
          </div>
          
          <div class="mb-2">
            <label class="form-label">Foto</label>
            <input type="file" name="foto" class="form-control">
          </div>
          
          <div class="mb-2">
            <label class="form-label">Fundación</label>
            <input type="text" name="fundacion" class="form-control">
          </div>
          
          <div class="mb-2">
            <label class="form-label">Hermano Mayor</label>
            <input type="text" name="hermano_mayor" class="form-control">
          </div>
          
          <div class="mb-2">
            <label class="form-label">Lugar de Salida</label>
            <input type="text" name="lugar_salida" class="form-control">
          </div>
          
          <div class="mb-2">
            <label class="form-label">Día</label>
            <input type="date" name="dia" class="form-control" required>
          </div>
          
          <div class="mb-2">
            <label class="form-label">Hora de Salida</label>
            <input type="time" name="hora_salida" class="form-control" required>
          </div>
          
          <div class="mb-2">
            <label class="form-label">Estado</label>
            <select name="estado" class="form-select">
              <?php foreach (['pendiente','en curso','retrasada','suspendida','finalizada'] as $e): ?>
                <option value="<?= $e ?>"><?= ucfirst($e) ?></option>
              <?php endforeach ?>
            </select>
          </div>
          
          <button type="submit" class="btn btn-success w-100 mt-2">Añadir Hermandad</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal para editar hermandad -->
<div class="modal fade" id="editarModal" tabindex="-1" aria-labelledby="editarModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editarModalLabel">Editar Hermandad</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post">
        <input type="hidden" name="accion" value="editar">
        <input type="hidden" name="id" id="edit-id">
        <div class="modal-body">
          <div class="mb-2">
            <label class="form-label">Día</label>
            <input type="date" name="dia" id="edit-dia" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Hora de Salida</label>
            <input type="time" name="hora_salida" id="edit-hora" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Estado</label>
            <select name="estado" id="edit-estado" class="form-select">
              <?php foreach (['pendiente','en curso','retrasada','suspendida','finalizada', 'programada'] as $e): ?>
                <option value="<?= $e ?>"><?= ucfirst($e) ?></option>
              <?php endforeach ?>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Configurar modal de edición
  document.querySelectorAll('.btn-editar').forEach(btn => {
    btn.addEventListener('click', function() {
      const h = JSON.parse(this.getAttribute('data-h'));
      document.getElementById('edit-id').value = h.id;
      document.getElementById('edit-dia').value = h.dia;
      document.getElementById('edit-hora').value = h.hora_salida;
      document.getElementById('edit-estado').value = h.estado;
    });
  });
});
</script>

<?php include 'includes/footer.php'; ?>

