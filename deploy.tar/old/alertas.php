<?php
include 'includes/header.php';
include 'includes/db.php';

// Insertar nueva alerta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_hermandad'], $_POST['tipo'], $_POST['alerta'])) {
  try {
    $stmt = $pdo->prepare("INSERT INTO alertas (id_hermandad, tipo, alerta) VALUES (?, ?, ?)");
    $stmt->execute([$_POST['id_hermandad'], $_POST['tipo'], $_POST['alerta']]);
    echo "<div class='alert alert-success'>Alerta publicada correctamente</div>";
    // Redirigir después de un breve retraso para mostrar el mensaje
    echo "<script>setTimeout(function() { window.location.href = 'alertas.php'; }, 1500);</script>";
  } catch (PDOException $e) {
    echo "<div class='alert alert-danger'>Error al publicar la alerta: " . $e->getMessage() . "</div>";
  }
}

// Eliminar alerta
if (isset($_GET['eliminar'])) {
  try {
    $stmt = $pdo->prepare("DELETE FROM alertas WHERE id = ?");
    $stmt->execute([$_GET['eliminar']]);
    echo "<div class='alert alert-success'>Alerta eliminada correctamente</div>";
    // Redirigir después de un breve retraso para mostrar el mensaje
    echo "<script>setTimeout(function() { window.location.href = 'alertas.php'; }, 1500);</script>";
  } catch (PDOException $e) {
    echo "<div class='alert alert-danger'>Error al eliminar la alerta: " . $e->getMessage() . "</div>";
  }
}

// Obtener todas las alertas con nombre de hermandad
$stmt = $pdo->query("SELECT a.*, h.nombre AS hermandad
                     FROM alertas a
                     JOIN hermandades h ON a.id_hermandad = h.id
                     ORDER BY a.fecha DESC");
$alertas = $stmt->fetchAll();

// Obtener hermandades para el select
$hermandades = $pdo->query("SELECT id, nombre FROM hermandades ORDER BY nombre")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
   <h2 class="mb-0 fs-2 fs-md-3 fs-lg-2">Alertas</h2>
</div>

<div class="row">
  <!-- Listado de alertas -->
  <div class="col-md-8">
    <div class="card shadow-sm mb-4">
      <div class="card-header bg-warning text-dark">Alertas registradas</div>
      <div class="card-body p-2">
        <?php if (count($alertas) === 0): ?>
          <p class="text-muted">No hay alertas registradas.</p>
        <?php else: ?>
          <table class="table table-sm">
            <thead class="table-light">
              <tr>
                <th>Hermandad</th>
                <th>Tipo</th>
                <th>Mensaje</th>
                <th>Fecha</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($alertas as $a): ?>
                <tr>
                  <td><?= htmlspecialchars($a['hermandad']) ?></td>
                  <td><strong><?= htmlspecialchars($a['tipo']) ?></strong></td>
                  <td><?= nl2br(htmlspecialchars($a['alerta'])) ?></td>
                  <td><?= date('d/m H:i', strtotime($a['fecha'])) ?></td>
                  <td><a href="?eliminar=<?= $a['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro de eliminar esta alerta?')">🗑️</a></td>
                </tr>
              <?php endforeach ?>
            </tbody>
          </table>
        <?php endif ?>
      </div>
    </div>
  </div>

  <!-- Formulario nueva alerta -->
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-header bg-secondary text-white">Nueva alerta</div>
      <div class="card-body">
        <form method="post">
          <div class="mb-2">
            <label class="form-label">Hermandad</label>
            <select name="id_hermandad" class="form-select" required>
              <option value="">Selecciona una</option>
              <?php foreach ($hermandades as $h): ?>
                <option value="<?= $h['id'] ?>"><?= htmlspecialchars($h['nombre']) ?></option>
              <?php endforeach ?>
            </select>
          </div>
          <div class="mb-2">
            <label class="form-label">Tipo</label>
            <select name="tipo" class="form-select" required>
              <option value="info">Información</option>
              <option value="retraso">Retraso</option>
              <option value="adelanto">Adelanto</option>
              <option value="cancelacion">Cancelación</option>
            </select>
          </div>
          <div class="mb-2">
            <label class="form-label">Mensaje</label>
            <textarea name="alerta" class="form-control" rows="4" required></textarea>
          </div>
          <button type="submit" class="btn btn-success w-100">Publicar alerta</button>
        </form>
      </div>
    </div>
  </div>
</div>


<?php include 'includes/footer.php'; ?>

