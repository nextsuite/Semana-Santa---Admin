<?php
include 'includes/header.php';
include 'includes/db.php';

$id_hermandad = $_GET['id'] ?? null;
if (!$id_hermandad) {
  echo "<p class='text-danger'>Falta el ID de la hermandad.</p>";
  include 'includes/footer.php';
  exit;
}

// Obtener info de la hermandad
$stmt = $pdo->prepare("SELECT nombre, hora_salida FROM hermandades WHERE id = ?");
$stmt->execute([$id_hermandad]);
$hermandad = $stmt->fetch();
$nombre_hermandad = $hermandad['nombre'];
$hora_salida = $hermandad['hora_salida'];

// Insertar nuevo punto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['accion'] === 'crear') {
  $stmt = $pdo->prepare("INSERT INTO recorridos (id_hermandad, orden, punto, minutos, tipo)
                         VALUES (?, ?, ?, ?, ?)");
  $stmt->execute([
    $id_hermandad,
    $_POST['orden'],
    $_POST['punto'],
    $_POST['minutos'],
    $_POST['tipo']
  ]);
  header("Location: recorridos.php?id=$id_hermandad");
  exit;
}

// Editar punto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['accion'] === 'editar') {
  $stmt = $pdo->prepare("UPDATE recorridos SET orden=?, punto=?, minutos=?, tipo=? WHERE id=? AND id_hermandad=?");
  $stmt->execute([
    $_POST['orden'],
    $_POST['punto'],
    $_POST['minutos'],
    $_POST['tipo'],
    $_POST['id'],
    $id_hermandad
  ]);
  header("Location: recorridos.php?id=$id_hermandad");
  exit;
}

// Eliminar punto
if (isset($_GET['eliminar'])) {
  $stmt = $pdo->prepare("DELETE FROM recorridos WHERE id = ? AND id_hermandad = ?");
  $stmt->execute([$_GET['eliminar'], $id_hermandad]);
  header("Location: recorridos.php?id=$id_hermandad");
  exit;
}

// Obtener recorrido
$stmt = $pdo->prepare("SELECT * FROM recorridos WHERE id_hermandad = ? ORDER BY orden ASC");
$stmt->execute([$id_hermandad]);
$recorrido = $stmt->fetchAll();

// Calcular horas estimadas acumuladas
$hora_actual = DateTime::createFromFormat('H:i:s', $hora_salida) ?: DateTime::createFromFormat('H:i', $hora_salida);
$hora_estimada = $hora_actual->format('H:i');
$hora_estimada_por_punto = [];

// Insertar punto de salida virtual
array_unshift($recorrido, [
  'id' => 0,
  'orden' => 0,
  'punto' => 'Salida',
  'minutos' => 0,
  'tipo' => 'salida',
  'hora' => $hora_estimada
]);

foreach ($recorrido as $index => $punto) {
  if ($index === 0) {
    $hora_estimada_por_punto[$index] = $hora_actual->format('H:i');
  } else {
    $hora_actual->modify("+{$punto['minutos']} minutes");
    $hora_estimada_por_punto[$index] = $hora_actual->format('H:i');
  }
}
?>

<div class="d-flex flex-wrap justify-content-between align-items-center align-content-center mb-4">
  <div class="d-flex align-items-center gap-3">
    <a href="/admin/index.php" class="btn btn-secondary btn-sm rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
      <i style="font-size:32px;" class="bi bi-arrow-left-short"></i>
    </a>
    <h2 class="mb-0 fs-2 fs-md-3 fs-lg-2">Recorrido de <?= htmlspecialchars($nombre_hermandad) ?></h2>
  </div>
  <nav class="d-none d-md-block" aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="/admin/index.php">Hermandades</a></li>
		<li class="breadcrumb-item"><?= htmlspecialchars($nombre_hermandad) ?></li>
      <li class="breadcrumb-item active" aria-current="page">Recorrido</li>
    </ol>
  </nav>
</div>

<div class="row">
  <!-- Tabla del recorrido -->
  <div class="col-md-8">
    <div class="card shadow-sm mb-4">
      <div class="card-header bg-primary text-white">Puntos del recorrido</div>
      <div class="card-body p-2">
		  <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead class="table-light">
            <tr>
              <th>Orden</th>
              <th>Punto</th>
              <th>Min.</th>
              <th>Hora estimada</th>
              <th>Tipo</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recorrido as $i => $punto): ?>
              <?php $hora_estimada = $hora_estimada_por_punto[$i] ?? '--'; ?>
              <?php if ($punto['id'] == 0): ?>
                <tr class="table-info">
                  <td><?= $punto['orden'] ?></td>
                  <td><?= htmlspecialchars($punto['punto']) ?></td>
                  <td><?= $punto['minutos'] ?></td>
                  <td><?= $hora_estimada ?></td>
                  <td><?= ucfirst($punto['tipo']) ?></td>
                  <td><span class="text-muted">—</span></td>
                </tr>
              <?php else: ?>
                <tr>
                  <form method="post">
                    <input type="hidden" name="accion" value="editar">
                    <input type="hidden" name="id" value="<?= $punto['id'] ?>">
                    <td><input type="number" name="orden" value="<?= $punto['orden'] ?>" class="form-control form-control-sm" required></td>
                    <td><input type="text" name="punto" value="<?= htmlspecialchars($punto['punto']) ?>" class="form-control form-control-sm" required></td>
                    <td><input type="number" name="minutos" value="<?= $punto['minutos'] ?>" class="form-control form-control-sm" required></td>
                    <td><?= $hora_estimada ?></td>
                    <td>
                      <select name="tipo" class="form-select form-select-sm">
                        <?php foreach (['punto','carrera_oficial','santa_cruz','entrada'] as $tipo): ?>
                          <option value="<?= $tipo ?>" <?= $punto['tipo'] === $tipo ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ', $tipo)) ?></option>
                        <?php endforeach ?>
                      </select>
                    </td>
                    <td>
                      <button class="btn btn-sm btn-success">💾</button>
                      <a href="?id=<?= $id_hermandad ?>&eliminar=<?= $punto['id'] ?>" class="btn btn-sm btn-danger">🗑️</a>
                    </td>
                  </form>
                </tr>
              <?php endif ?>
            <?php endforeach ?>
          </tbody>
        </table>
		  </div>
      </div>
    </div>
  </div>

  <!-- Añadir nuevo punto -->
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-header bg-secondary text-white">Añadir nuevo punto</div>
      <div class="card-body">
        <form method="post">
          <input type="hidden" name="accion" value="crear">
          <div class="mb-2">
            <label class="form-label">Orden</label>
            <input type="number" name="orden" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Nombre del punto</label>
            <input type="text" name="punto" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Minutos desde anterior</label>
            <input type="number" name="minutos" class="form-control" required>
          </div>
          <div class="mb-2">
            <label class="form-label">Tipo</label>
            <select name="tipo" class="form-select">
              <option value="punto" selected>Punto</option>
              <option value="carrera_oficial">Carrera Oficial</option>
              <option value="santa_cruz">Santa Cruz</option>
              <option value="entrada">Entrada</option>
            </select>
          </div>
          <button type="submit" class="btn btn-success w-100">Añadir</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>