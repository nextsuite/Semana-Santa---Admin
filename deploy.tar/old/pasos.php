<?php
include 'includes/header.php';
include 'includes/db.php';

$id_hermandad = $_GET['id'] ?? null;
if (!$id_hermandad) {
  echo "<p class='text-danger'>Falta el ID de la hermandad.</p>";
  include 'includes/footer.php';
  exit;
}

// Obtener info de la hermandad
$stmt = $pdo->prepare("SELECT nombre FROM hermandades WHERE id = ?");
$stmt->execute([$id_hermandad]);
$hermandad = $stmt->fetch();
$nombre_hermandad = $hermandad['nombre'] ?? '';

// Añadir paso
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion']) && $_POST['accion'] === 'crear') {
  $nombre = $_POST['nombre'];
  $foto_de = $_POST['foto_de'];
  $autor = $_POST['autor'];
  $anio = $_POST['anio'];
  $capataz = $_POST['capataz'];
  $costaleros = $_POST['costaleros'];
  $acompanamiento_musical = $_POST['acompanamiento_musical'];

  // Crear directorio de uploads si no existe
  $target_dir = "../uploads/";
  if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true);
  }

  // Subir imagen
  $foto = null;
  if (!empty($_FILES['foto']['name'])) {
    $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
    $nombre_foto = uniqid("paso_") . '.' . $ext;
    $target_file = $target_dir . $nombre_foto;

    if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
      $foto = $nombre_foto;
    } else {
      echo "<div class='alert alert-danger'>Error al subir la imagen</div>";
    }
  }

  try {
    $stmt = $pdo->prepare("INSERT INTO pasos (id_hermandad, nombre, foto, foto_de, autor, anio, capataz, costaleros, acompanamiento_musical) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
      $id_hermandad, 
      $nombre, 
      $foto,
	  $foto_de, 
      $autor, 
      $anio, 
      $capataz, 
      $costaleros, 
      $acompanamiento_musical
    ]);
    
    echo "<div class='alert alert-success'>Paso añadido correctamente</div>";
    // Redirigir después de un breve retraso para mostrar el mensaje
    echo "<script>setTimeout(function() { window.location.href = 'pasos.php?id=$id_hermandad'; }, 1500);</script>";
  } catch (PDOException $e) {
    echo "<div class='alert alert-danger'>Error al añadir el paso: " . $e->getMessage() . "</div>";
  }
}

// Eliminar paso
if (isset($_GET['eliminar'])) {
  try {
    $stmt = $pdo->prepare("DELETE FROM pasos WHERE id = ? AND id_hermandad = ?");
    $stmt->execute([$_GET['eliminar'], $id_hermandad]);
    echo "<div class='alert alert-success'>Paso eliminado correctamente</div>";
    // Redirigir después de un breve retraso para mostrar el mensaje
    echo "<script>setTimeout(function() { window.location.href = 'pasos.php?id=$id_hermandad'; }, 1500);</script>";
  } catch (PDOException $e) {
    echo "<div class='alert alert-danger'>Error al eliminar el paso: " . $e->getMessage() . "</div>";
  }
}

// Obtener pasos
$stmt = $pdo->prepare("SELECT * FROM pasos WHERE id_hermandad = ?");
$stmt->execute([$id_hermandad]);
$pasos = $stmt->fetchAll();
?>

<div class="d-flex flex-wrap justify-content-between align-items-center align-content-center mb-4">
  <div class="d-flex align-items-center gap-3">
    <a href="/admin/index.php" class="btn btn-secondary btn-sm rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
      <i style="font-size:32px;" class="bi bi-arrow-left-short"></i>
    </a>
    <h2 class="mb-0 fs-2 fs-md-3 fs-lg-2">Pasos de <?= htmlspecialchars($nombre_hermandad) ?></h2>
  </div>
  <nav class="d-none d-md-block" aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="/admin/index.php">Hermandades</a></li>
		<li class="breadcrumb-item"><?= htmlspecialchars($nombre_hermandad) ?></li>
      <li class="breadcrumb-item active" aria-current="page">Pasos</li>
    </ol>
  </nav>
</div>

<div class="row">
  <!-- Lista de pasos -->
  <div class="col-md-8">
    <div class="card shadow-sm mb-4">
      <div class="card-header bg-primary text-white">Listado de pasos</div>
      <div class="card-body">
        <?php if (count($pasos) === 0): ?>
          <p class="text-muted">Esta hermandad no tiene pasos registrados.</p>
        <?php else: ?>
          <div class="table-responsive">
            <table class="table table-striped align-middle">
              <thead class="table-light">
                <tr>
                  <th>Foto</th>
                  <th>Nombre</th>
                  <th>Autor</th>
                  <th>Año</th>
                  <th>Capataz</th>
                  <th>Costaleros</th>
                  <th>Acompañamiento Musical</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($pasos as $paso): ?>
                  <tr>
                    <td>
                      <?php if ($paso['foto']): ?>
                        <img src="../uploads/<?= $paso['foto'] ?>" width="50" height="50" style="object-fit: cover; border-radius: 4px;">
                      <?php else: ?>
                        <span class="text-muted">—</span>
                      <?php endif ?>
                    </td>
                    <td class="fw-bold"><?= htmlspecialchars($paso['nombre']) ?></td>
                    <td><?= htmlspecialchars($paso['autor']) ?></td>
                    <td><?= htmlspecialchars($paso['anio']) ?></td>
                    <td><?= htmlspecialchars($paso['capataz']) ?></td>
                    <td><?= htmlspecialchars($paso['costaleros']) ?></td>
                    <td><?= htmlspecialchars($paso['acompanamiento_musical']) ?></td>
                    <td>
                      <a href="?id=<?= $id_hermandad ?>&eliminar=<?= $paso['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro de eliminar este paso?')">🗑️</a>
                    </td>
                  </tr>
                <?php endforeach ?>
              </tbody>
            </table>
          </div>
        <?php endif ?>
      </div>
    </div>
  </div>

  <!-- Añadir nuevo paso -->
  <div class="col-md-4">
    <div class="card shadow-sm">
      <div class="card-header bg-secondary text-white">Añadir paso</div>
      <div class="card-body">
        <form method="post" enctype="multipart/form-data">
          <input type="hidden" name="accion" value="crear">

          <div class="mb-2">
            <label class="form-label">Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
          </div>

          <div class="mb-2">
            <label class="form-label">Foto</label>
            <input type="file" name="foto" class="form-control">
          </div>

          <div class="mb-2">
            <label class="form-label">Autor</label>
            <input type="text" name="autor" class="form-control">
          </div>

          <div class="mb-2">
            <label class="form-label">Año</label>
            <input type="text" name="anio" class="form-control">
          </div>

          <div class="mb-2">
            <label class="form-label">Capataz</label>
            <input type="text" name="capataz" class="form-control">
          </div>

          <div class="mb-2">
            <label class="form-label">Costaleros</label>
            <input type="text" name="costaleros" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label">Acompañamiento musical</label>
            <input type="text" name="acompanamiento_musical" class="form-control">
          </div>

          <button type="submit" class="btn btn-success w-100">Añadir paso</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

