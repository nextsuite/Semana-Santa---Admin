<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="author" content="Next Suite">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Semana Santa de Écija – Iniciar sesión</title>
  <link rel="icon" href="assets/img/favicon.ico" type="image/x-icon"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/litera/bootstrap.min.css" 
        integrity="sha384-enpDwFISL6M3ZGZ50Tjo8m65q06uLVnyvkFO3rsoW0UC15ATBFz3QEhr3hmxpYsn" 
        crossorigin="anonymous">
</head>

<body class="h-100">
  <section class="h-100">
    <div class="container h-100">
      <div class="row justify-content-center align-items-center min-vh-100">
        <div class="col-xxl-4 col-xl-5 col-lg-5 col-md-7 col-sm-9">
          <div class="text-center my-5">
            <img src="assets/images/logo-color.png" alt="logo" width="300px">
          </div>
          <div class="card shadow-lg">
            <div class="card-header py-3 border-0">
              <div class="text-center">
                <img src="assets/images/cuentadenext.png" width="220px"/>
              </div>
            </div>
            <div class="card-body p-5">
              <h4 class="fs-4 card-title fw-bold mb-4">Iniciar sesión</h4>
				<div id="alertContainer"></div>
              <!-- Formulario de Login -->
              <form id="loginForm" class="needs-validation" novalidate="" autocomplete="on">
                <div class="mb-3">
                  <label class="mb-2 text-muted" for="username">Usuario</label>
                  <input id="username" type="text" class="form-control" name="username" required autofocus>
                </div>
                <div class="mb-3">
                  <div class="mb-2 w-100">
                    <label class="text-muted" for="password">Contraseña</label>
                  </div>
                  <input id="password" type="password" class="form-control" name="password" required>
                </div>
                <div class="d-flex align-items-center">
                  <button type="submit" class="btn btn-primary ms-auto">
                    Iniciar sesión
                  </button>
                </div>
              </form>
              <!-- Fin Formulario -->
            </div>
          </div>
          <div class="text-center mt-5 text-muted">
            Copyright &copy; <?php echo date("Y");?> &mdash; Next Suite
          </div>
        </div>
      </div>
    </div>
  </section>
	
	<script src="assets/js/login.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.slim.js" integrity="sha512-docBEeq28CCaXCXN7cINkyQs0pRszdQsVBFWUd+pLNlEk3LDlSDDtN7i1H+nTB8tshJPQHS0yu0GW9YGFd/CRg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>