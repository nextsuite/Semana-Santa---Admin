 /**
     * Muestra una alerta de Bootstrap en el contenedor #alertContainer
     * @param {string} message - Mensaje a mostrar
     * @param {string} type - Tipo de alerta (success, danger, warning, info)
     */
    function showAlert(message, type = 'success') {
      const alertContainer = document.getElementById('alertContainer');
      // Insertamos la alerta dentro del contenedor
      alertContainer.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
          ${message}
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      `;
    }

    // Escuchamos el evento submit del formulario
    document.getElementById('loginForm').addEventListener('submit', async function(event) {
      event.preventDefault(); // Evita el envío normal del formulario

      // Obtenemos los valores de los campos
      const username = document.getElementById('username').value.trim();
      const password = document.getElementById('password').value.trim();

      // Reseteamos cualquier alerta previa
      document.getElementById('alertContainer').innerHTML = '';

      if (!username || !password) {
        showAlert('Por favor, completa todos los campos.', 'warning');
        return;
      }

      try {
        // Realizamos la petición a la API
        const response = await fetch('https://nextsuite.es/intranet/public/api/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            username: username,
            password: password,
            device_name: 'App Semana Santa de Écija (Admin)' // Ajusta si tu API lo requiere
          })
        });

        const data = await response.json();

        // Verificamos si el login fue exitoso
        if (response.ok && data.token) {
          // Guardamos el token en localStorage (ejemplo)
          localStorage.setItem('authToken', data.token);

          // Mostramos alerta de éxito
          showAlert('¡Inicio de sesión exitoso! Redirigiendo...', 'success');

          // Redireccionar a otra página protegida (puede ser dashboard, etc.)
          setTimeout(() => {
            window.location.href = 'index.php';
          }, 1500);

        } else {
          // Si la API devuelve error o no hay token
          showAlert('Error al iniciar sesión. Credenciales inválidas.', 'danger');
        }
      } catch (error) {
        console.error('Error en la petición:', error);
        showAlert('Ha ocurrido un error al intentar iniciar sesión.', 'danger');
      }
    });