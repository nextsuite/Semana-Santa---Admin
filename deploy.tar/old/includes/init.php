<?php
// Crear directorios necesarios si no existen
$directories = [
    'uploads',
    'uploads/escudos',
    'uploads/fotos',
    'uploads/pasos'
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
}
?>

