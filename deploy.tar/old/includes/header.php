<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel - App Semana Santa de Écija</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/litera/bootstrap.min.css" integrity="sha384-enpDwFISL6M3ZGZ50Tjo8m65q06uLVnyvkFO3rsoW0UC15ATBFz3QEhr3hmxpYsn" crossorigin="anonymous">
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .navbar-brand {
      font-weight: bold;
      letter-spacing: 1px;
    }
	  .navbar {
	  background-color:#541e1b;
	  }
	</style>
	<script>
		const token = localStorage.getItem('authToken');
if (!token) {
  // No hay token, redirige al login
  window.location.href = 'login.php';
}
	</script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand mr-4" href="/admin/index.php">
  <img src="assets/images/logo.png" alt="Logo" height="30" class="d-inline-block align-text-top">
</a>

    <!-- Botón hamburguesa para móviles -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarPanel" aria-controls="navbarPanel" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menú colapsable -->
    <div class="collapse navbar-collapse" id="navbarPanel">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>" href="/admin/index.php">Hermandades</a></li>
        <li class="nav-item"><a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'alertas.php' ? 'active' : '' ?>" href="/admin/alertas.php">Alertas</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container-fluid">